globalThis.__BUILD_MANIFEST = {
  "polyfillFiles": [
    "static/chunks/polyfills.js"
  ],
  "devFiles": [],
  "lowPriorityFiles": [
    "static/development/_buildManifest.js",
    "static/development/_ssgManifest.js"
  ],
  "rootMainFiles": [],
  "rootMainFilesTree": {},
  "pages": {
    "/_app": []
  }
};
